package com.legitfocustarget.mixin;

import com.legitfocustarget.FocusTargetManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityDamage", at = @At("HEAD"))
    private void legitFocusTarget$onEntityDamage(EntityDamageS2CPacket packet, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity local = client.player;
        ClientWorld world = client.world;
        if (local == null || world == null) return;

        Entity damaged = world.getEntityById(packet.entityId());
        if (!(damaged instanceof PlayerEntity target) || target == local) return;

        // The server-reported cause/direct source must identify the local player.
        if (packet.sourceCauseId() != local.getId() && packet.sourceDirectId() != local.getId()) return;
        FocusTargetManager.setFocusTarget(target);
    }
}
