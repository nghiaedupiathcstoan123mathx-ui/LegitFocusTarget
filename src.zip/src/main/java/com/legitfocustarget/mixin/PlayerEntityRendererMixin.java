package com.legitfocustarget.mixin;

import com.legitfocustarget.FocusTargetManager;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void legitFocusTarget$modifyRenderState(PlayerEntity player, PlayerEntityRenderState state,
                                                    float tickProgress, CallbackInfo ci) {
        if (!FocusTargetManager.isFocusTarget(player) || state.displayName == null) return;
        Text highlighted = Text.empty()
                .append(Text.literal("[🎯] ").styled(style -> style.withBold(true).withColor(0xFFFF00)))
                .append(state.displayName.copy().styled(style -> style.withColor(0xFFFF00)));
        state.displayName = highlighted;
    }
}
