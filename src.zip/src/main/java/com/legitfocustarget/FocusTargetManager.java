package com.legitfocustarget;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.Nullable;

public final class FocusTargetManager {
    private static final int TARGET_DURATION_TICKS = 200;
    private static final double MAX_DISTANCE_SQUARED = 900.0;

    private static @Nullable PlayerEntity focusTarget;
    private static int remainingTicks;

    private FocusTargetManager() {}

    public static void setFocusTarget(@Nullable PlayerEntity target) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity local = client.player;
        if (target == null || local == null || target == local || !isValidTarget(local, target)) {
            clear();
            return;
        }
        focusTarget = target;
        remainingTicks = TARGET_DURATION_TICKS;
    }

    public static void tick(MinecraftClient client) {
        if (focusTarget == null) return;
        if (client.player == null || client.world == null || --remainingTicks <= 0
                || !isValidTarget(client.player, focusTarget)) {
            clear();
        }
    }

    public static boolean isFocusTarget(PlayerEntity player) {
        return focusTarget == player && remainingTicks > 0;
    }

    public static void clear() {
        focusTarget = null;
        remainingTicks = 0;
    }

    private static boolean isValidTarget(ClientPlayerEntity local, PlayerEntity target) {
        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null || target.getWorld() != world || target.isRemoved() || !target.isAlive()) return false;
        if (target.isInvisible() || target.hasStatusEffect(StatusEffects.INVISIBILITY)) return false;
        if (local.squaredDistanceTo(target) > MAX_DISTANCE_SQUARED) return false;
        return hasDirectLineOfSight(local, target, world);
    }

    private static boolean hasDirectLineOfSight(ClientPlayerEntity local, PlayerEntity target, ClientWorld world) {
        Vec3d start = local.getEyePos();
        Vec3d end = target.getEyePos();
        BlockHitResult hit = world.raycast(new RaycastContext(
                start, end,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                local
        ));
        return hit.getType() == HitResult.Type.MISS;
    }
}
